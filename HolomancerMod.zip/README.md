# Holomancer
### **THIS IS AN ALPHA RELEASE. IT HAS JANKY ANIMATIONS, MESSY UNOPTIMIZED CODE AND A LOT OF MISSING FEATURES.**
#### This mod will be updated with fixes and new features. It will also most likely be completely rewritten from scratch before an actual 1.0 release.
Even though she's unfinished, she's still a lot of fun to play.  
We appreciate any and all feedback. Contact us on Discord: **Vegan for the animals#6293** and **Liamono#1206**.

[![](https://cdn.discordapp.com/attachments/835219836585377812/839981261984366602/Screenshot_159.png)]()

[![](https://cdn.discordapp.com/attachments/835219836585377812/839981267915505724/Screenshot_160.png)]()

[![](https://cdn.discordapp.com/attachments/835219836585377812/839981271614619668/Screenshot_161.png)]()

[HenryMod](https://github.com/ArcPh1r3/HenryTutorial) by rob was used as a base. There's probably a bunch of leftover code from Henry - especially in the unity project. A big thanks to rob for the HenryMod, it made developing this project so much easier and streamlined.

## Changelog
- 0.0.2: Minor alpha update. Improved descriptions on the skills and did some balance changes. Fencer attacks should be more reliable now. Added a recall/teleport function to holograms for improved reliability. 
- 0.0.1: Alpha.

## Credits  
#### Coding:
Vegan for the animals, Liamono
#### Open source code from:
rob, KomradeSpectre
#### Animations and models:
Liamono
#### Base models used:
https://sketchfab.com/3d-models/magic-staff-f0a358176247449fb10d9ceec077a85b  
https://sketchfab.com/3d-models/sorceress-character-42f68cb8517c43d0a9dfd1a7a8dbd9fb
